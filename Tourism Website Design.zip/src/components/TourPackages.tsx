import { Check, Calendar, MapPin, Users, ArrowRight } from 'lucide-react';
import type { Page } from '../App';

interface TourPackagesProps {
  onNavigate: (page: Page) => void;
}

export function TourPackages({ onNavigate }: TourPackagesProps) {
  const packages = [
    {
      id: 'bali-basic',
      destination: 'Bali, Indonesia',
      name: 'Basic Package',
      duration: '5 Days / 4 Nights',
      price: 74999,
      image: 'https://images.unsplash.com/photo-1581032841303-0ba9e894ebc3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxCYWxpJTIwSW5kb25lc2lhJTIwdGVtcGxlfGVufDF8fHx8MTc3MDE4ODU4OXww&ixlib=rb-4.1.0&q=80&w=1080',
      inclusions: [
        'Airport transfers',
        'Budget hotel accommodation',
        'Daily breakfast',
        'Temple tour',
        'Basic travel insurance'
      ],
      popular: false
    },
    {
      id: 'bali-standard',
      destination: 'Bali, Indonesia',
      name: 'Standard Package',
      duration: '6 Days / 5 Nights',
      price: 107999,
      image: 'https://images.unsplash.com/photo-1680096025643-d41f6aeff989?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGJlYWNoJTIwcmVzb3J0fGVufDF8fHx8MTc3MDIzMjQ5MHww&ixlib=rb-4.1.0&q=80&w=1080',
      inclusions: [
        'Airport transfers',
        '4-star hotel accommodation',
        'Daily breakfast & 3 dinners',
        'Private car with driver',
        'All temple tours & entrance fees',
        'Ubud cultural activities',
        'One spa treatment',
        'Comprehensive travel insurance'
      ],
      popular: true
    },
    {
      id: 'bali-luxury',
      destination: 'Bali, Indonesia',
      name: 'Luxury Package',
      duration: '7 Days / 6 Nights',
      price: 207999,
      image: 'https://images.unsplash.com/photo-1738407282253-979e31f45785?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHBvb2x8ZW58MXx8fHwxNzcwMjcwMjIwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      inclusions: [
        'Private airport transfers',
        'Luxury resort accommodation',
        'All meals included',
        'Private tour guide & driver',
        'All activities & entrance fees',
        'Helicopter tour over Mount Agung',
        'Private beach club access',
        'Daily spa treatments',
        'Premium travel insurance',
        'Personal concierge service'
      ],
      popular: false
    },
    {
      id: 'santorini-standard',
      destination: 'Santorini, Greece',
      name: 'Standard Package',
      duration: '5 Days / 4 Nights',
      price: 132999,
      image: 'https://images.unsplash.com/photo-1719547710130-7ce8ae694d63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdWx0dXJhbCUyMHRlbXBsZSUyMGFzaWF8ZW58MXx8fHwxNzcwMTc3NTU2fDA&ixlib=rb-4.1.0&q=80&w=1080',
      inclusions: [
        'Airport transfers',
        '4-star hotel with caldera view',
        'Daily breakfast',
        'Sunset cruise with dinner',
        'Island tour with wine tasting',
        'Travel insurance'
      ],
      popular: false
    },
    {
      id: 'maldives-luxury',
      destination: 'Maldives',
      name: 'Luxury Package',
      duration: '6 Days / 5 Nights',
      price: 239999,
      image: 'https://images.unsplash.com/photo-1768735693726-4aead6ae541d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlcmZhbGwlMjBuYXR1cmUlMjB0cm9waWNhbHxlbnwxfHx8fDE3NzAxODcwNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      inclusions: [
        'Seaplane transfers',
        'Overwater villa accommodation',
        'All-inclusive meals & drinks',
        'Snorkeling & diving trips',
        'Spa treatments',
        'Sunset fishing excursion',
        'Premium travel insurance'
      ],
      popular: true
    },
    {
      id: 'patagonia-adventure',
      destination: 'Patagonia, Argentina',
      name: 'Adventure Package',
      duration: '8 Days / 7 Nights',
      price: 157999,
      image: 'https://images.unsplash.com/photo-1595368062405-e4d7840cba14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGhpa2luZyUyMGFkdmVudHVyZXxlbnwxfHx8fDE3NzAyMzg1NjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
      inclusions: [
        'Airport transfers',
        'Lodge accommodation',
        'Daily meals',
        'Glacier trekking tours',
        'El Chalten hiking expeditions',
        'Expert mountain guides',
        'All equipment rental',
        'Travel insurance'
      ],
      popular: false
    }
  ];

  return (
    <div>
      {/* Header */}
      <section className="bg-gradient-to-r from-teal-600 to-blue-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-4">Tour Packages</h1>
          <p className="text-xl text-gray-100 max-w-3xl mx-auto">
            All-inclusive packages designed for hassle-free travel experiences
          </p>
        </div>
      </section>

      {/* Packages Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {packages.map((pkg) => (
            <div
              key={pkg.id}
              className={`bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all ${
                pkg.popular ? 'ring-4 ring-teal-600 transform scale-105' : ''
              }`}
            >
              {pkg.popular && (
                <div className="bg-teal-600 text-white text-center py-2 font-semibold">
                  MOST POPULAR
                </div>
              )}

              {/* Image */}
              <div className="relative h-48">
                <img
                  src={pkg.image}
                  alt={pkg.destination}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-3 left-3 bg-white px-3 py-1 rounded-full text-sm font-semibold">
                  {pkg.destination}
                </div>
              </div>

              {/* Content */}
              <div className="p-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                
                {/* Duration */}
                <div className="flex items-center text-gray-600 mb-4">
                  <Calendar className="w-4 h-4 mr-2" />
                  <span>{pkg.duration}</span>
                </div>

                {/* Price */}
                <div className="mb-6">
                  <span className="text-4xl font-bold text-teal-600">₹{pkg.price.toLocaleString('en-IN')}</span>
                  <span className="text-gray-600"> / person</span>
                </div>

                {/* Inclusions */}
                <div className="mb-6">
                  <h4 className="font-semibold text-gray-900 mb-3">What's Included:</h4>
                  <ul className="space-y-2">
                    {pkg.inclusions.map((inclusion, idx) => (
                      <li key={idx} className="flex items-start space-x-2 text-sm text-gray-700">
                        <Check className="w-4 h-4 text-teal-600 flex-shrink-0 mt-0.5" />
                        <span>{inclusion}</span>
                      </li>
                    ))}
                  </ul>
                </div>

                {/* CTA Buttons */}
                <div className="space-y-3">
                  <button
                    onClick={() => onNavigate('booking')}
                    className={`w-full py-3 rounded-lg font-semibold transition-colors ${
                      pkg.popular
                        ? 'bg-teal-600 text-white hover:bg-teal-700'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                    }`}
                  >
                    Book Now
                  </button>
                  <button
                    onClick={() => onNavigate('destination-details')}
                    className="w-full py-3 rounded-lg font-semibold text-teal-600 border-2 border-teal-600 hover:bg-teal-50 transition-colors flex items-center justify-center space-x-2"
                  >
                    <span>View Details</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Why Book Packages */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Why Book a Package?</h2>
            <p className="text-xl text-gray-600">Hassle-free travel with everything included</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="bg-white p-8 rounded-xl shadow-md text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-teal-100 text-teal-600 rounded-full mb-4">
                <MapPin className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Best Value</h3>
              <p className="text-gray-600">
                Save up to 30% compared to booking individually. All-inclusive pricing with no hidden costs.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-teal-100 text-teal-600 rounded-full mb-4">
                <Calendar className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">Expertly Planned</h3>
              <p className="text-gray-600">
                Carefully curated itineraries by travel experts to maximize your experience.
              </p>
            </div>

            <div className="bg-white p-8 rounded-xl shadow-md text-center">
              <div className="inline-flex items-center justify-center w-16 h-16 bg-teal-100 text-teal-600 rounded-full mb-4">
                <Users className="w-8 h-8" />
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">24/7 Support</h3>
              <p className="text-gray-600">
                Dedicated support team available throughout your journey for peace of mind.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Custom Package CTA */}
      <section className="bg-gradient-to-r from-teal-600 to-blue-600 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center text-white">
          <h2 className="text-3xl font-bold mb-4">Need a Custom Package?</h2>
          <p className="text-xl mb-8 text-gray-100">
            Let us create a personalized itinerary tailored to your preferences
          </p>
          <button
            onClick={() => onNavigate('about')}
            className="bg-white text-teal-600 px-8 py-4 rounded-lg font-semibold hover:bg-gray-100 transition-colors inline-flex items-center space-x-2"
          >
            <span>Contact Us</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>
    </div>
  );
}