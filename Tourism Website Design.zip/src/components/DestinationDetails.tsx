import { Calendar, Clock, MapPin, Wifi, Coffee, Waves, Wind, Check } from 'lucide-react';
import type { Page } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface DestinationDetailsProps {
  destinationId: string;
  onNavigate: (page: Page, destination?: string) => void;
}

export function DestinationDetails({ destinationId, onNavigate }: DestinationDetailsProps) {
  // Mock data - in real app, this would come from an API
  const destinationData: any = {
    bali: {
      name: 'Bali, Indonesia',
      tagline: 'The Island of Gods',
      heroImage: 'https://images.unsplash.com/photo-1581032841303-0ba9e894ebc3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxCYWxpJTIwSW5kb25lc2lhJTIwdGVtcGxlfGVufDF8fHx8MTc3MDE4ODU4OXww&ixlib=rb-4.1.0&q=80&w=1080',
      description: 'Bali is a tropical paradise that seamlessly blends natural beauty with rich cultural heritage. From pristine beaches and lush rice terraces to ancient temples and vibrant arts scene, Bali offers an unforgettable experience for every traveler. The island is known for its warm hospitality, delicious cuisine, and spiritual atmosphere that attracts millions of visitors each year.',
      culture: 'Balinese culture is deeply rooted in Hindu traditions, with daily offerings, temple ceremonies, and traditional dance performances. The island is home to over 10,000 temples, each with unique architecture and significance.',
      nature: 'Bali boasts diverse landscapes including volcanic mountains, terraced rice paddies, beautiful beaches, and lush rainforests. Mount Agung, the island\'s highest peak, offers challenging treks and spectacular sunrise views.',
      highlights: [
        'Tanah Lot Temple - Iconic sea temple on a rock formation',
        'Ubud Rice Terraces - UNESCO World Heritage site',
        'Sacred Monkey Forest - Ancient temple complex with playful monkeys',
        'Uluwatu Temple - Clifftop temple with traditional Kecak dance',
        'Seminyak Beach - Trendy beach clubs and stunning sunsets',
        'Tirta Empul - Holy spring water temple'
      ],
      bestTime: 'April to October (dry season)',
      recommendedDays: '5-7 Days',
      itinerary: [
        {
          day: 1,
          title: 'Arrival & South Bali Beaches',
          activities: [
            'Arrive at Ngurah Rai International Airport',
            'Check-in to your hotel in Seminyak',
            'Relax at Seminyak Beach',
            'Sunset dinner at beach club',
            'Explore local boutiques and cafes'
          ]
        },
        {
          day: 2,
          title: 'Ubud Cultural Experience',
          activities: [
            'Visit Tegalalang Rice Terraces',
            'Explore Sacred Monkey Forest Sanctuary',
            'Lunch at local warung with rice field views',
            'Visit Ubud Royal Palace',
            'Evening traditional Legong dance performance',
            'Shopping at Ubud Art Market'
          ]
        },
        {
          day: 3,
          title: 'Temple Tour & Sunset',
          activities: [
            'Early morning visit to Tirta Empul Holy Spring',
            'Coffee plantation tour and tasting',
            'Tanah Lot Temple tour',
            'Beachside lunch',
            'Afternoon at leisure',
            'Uluwatu Temple and Kecak Fire Dance at sunset'
          ]
        },
        {
          day: 4,
          title: 'Water Adventures',
          activities: [
            'Snorkeling or diving at Blue Lagoon',
            'Visit to Waterblow at Nusa Dua',
            'Lunch at Jimbaran Bay',
            'Spa treatment and Balinese massage',
            'Seafood dinner on the beach'
          ]
        },
        {
          day: 5,
          title: 'North Bali Exploration',
          activities: [
            'Visit Handara Gate',
            'Ulun Danu Beratan Temple on the lake',
            'Jatiluwih Rice Terraces',
            'Git Git Waterfall',
            'Return to hotel via scenic route'
          ]
        }
      ],
      hotels: [
        {
          id: 1,
          name: 'The Laguna Resort & Spa',
          category: 'Resort',
          rating: 5,
          image: 'https://images.unsplash.com/photo-1738407282253-979e31f45785?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHBvb2x8ZW58MXx8fHwxNzcwMjcwMjIwfDA&ixlib=rb-4.1.0&q=80&w=1080',
          price: 24999,
          distance: '2 km from Seminyak Beach',
          amenities: ['Wifi', 'Breakfast', 'Pool', 'AC']
        },
        {
          id: 2,
          name: 'Ubud Valley Resort',
          category: '5★',
          rating: 5,
          image: 'https://images.unsplash.com/photo-1680096025643-d41f6aeff989?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGJlYWNoJTIwcmVzb3J0fGVufDF8fHx8MTc3MDIzMjQ5MHww&ixlib=rb-4.1.0&q=80&w=1080',
          price: 15999,
          distance: '500m from Ubud Center',
          amenities: ['Wifi', 'Breakfast', 'Pool', 'AC']
        },
        {
          id: 3,
          name: 'Nusa Dua Beach Hotel',
          category: '5★',
          rating: 5,
          image: 'https://images.unsplash.com/photo-1768735693726-4aead6ae541d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlcmZhbGwlMjBuYXR1cmUlMjB0cm9waWNhbHxlbnwxfHx8fDE3NzAxODcwNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
          price: 20999,
          distance: 'Beachfront',
          amenities: ['Wifi', 'Breakfast', 'Pool', 'AC']
        },
        {
          id: 4,
          name: 'Canggu Surf Lodge',
          category: '3★',
          rating: 4,
          image: 'https://images.unsplash.com/photo-1595368062405-e4d7840cba14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGhpa2luZyUyMGFkdmVudHVyZXxlbnwxfHx8fDE3NzAyMzg1NjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
          price: 7499,
          distance: '300m from Canggu Beach',
          amenities: ['Wifi', 'Breakfast', 'Pool']
        }
      ],
      packages: [
        {
          id: 'basic',
          name: 'Basic Package',
          duration: '5 Days / 4 Nights',
          price: 74999,
          inclusions: [
            'Airport transfers',
            'Budget hotel accommodation',
            'Daily breakfast',
            'Temple tour',
            'Basic travel insurance'
          ]
        },
        {
          id: 'standard',
          name: 'Standard Package',
          duration: '6 Days / 5 Nights',
          price: 107999,
          inclusions: [
            'Airport transfers',
            '4-star hotel accommodation',
            'Daily breakfast & 3 dinners',
            'Private car with driver',
            'All temple tours & entrance fees',
            'Ubud cultural activities',
            'One spa treatment',
            'Comprehensive travel insurance'
          ]
        },
        {
          id: 'luxury',
          name: 'Luxury Package',
          duration: '7 Days / 6 Nights',
          price: 207999,
          inclusions: [
            'Private airport transfers',
            'Luxury resort accommodation',
            'All meals included',
            'Private tour guide & driver',
            'All activities & entrance fees',
            'Helicopter tour over Mount Agung',
            'Private beach club access',
            'Daily spa treatments',
            'Premium travel insurance',
            'Personal concierge service'
          ]
        }
      ]
    }
  };

  const destination = destinationData[destinationId] || destinationData.bali;

  const getAmenityIcon = (amenity: string) => {
    switch (amenity.toLowerCase()) {
      case 'wifi': return <Wifi className="w-4 h-4" />;
      case 'breakfast': return <Coffee className="w-4 h-4" />;
      case 'pool': return <Waves className="w-4 h-4" />;
      case 'ac': return <Wind className="w-4 h-4" />;
      default: return null;
    }
  };

  return (
    <div>
      {/* Hero Section */}
      <section className="relative h-[500px]">
        <ImageWithFallback
          src={destination.heroImage}
          alt={destination.name}
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-black/20"></div>
        <div className="absolute bottom-0 left-0 right-0 text-white p-8">
          <div className="max-w-7xl mx-auto">
            <h1 className="text-5xl font-bold mb-2">{destination.name}</h1>
            <p className="text-2xl text-gray-200">{destination.tagline}</p>
          </div>
        </div>
      </section>

      {/* Quick Info */}
      <section className="bg-white border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div className="flex items-center space-x-3">
              <Calendar className="w-6 h-6 text-teal-600" />
              <div>
                <p className="text-sm text-gray-600">Best Time to Visit</p>
                <p className="font-semibold">{destination.bestTime}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <Clock className="w-6 h-6 text-teal-600" />
              <div>
                <p className="text-sm text-gray-600">Recommended Duration</p>
                <p className="font-semibold">{destination.recommendedDays}</p>
              </div>
            </div>
            <div className="flex items-center space-x-3">
              <MapPin className="w-6 h-6 text-teal-600" />
              <div>
                <p className="text-sm text-gray-600">Location</p>
                <p className="font-semibold">{destination.name}</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Description */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
          <div className="lg:col-span-2">
            <h2 className="text-3xl font-bold text-gray-900 mb-6">About {destination.name}</h2>
            <p className="text-gray-700 text-lg mb-6 leading-relaxed">{destination.description}</p>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
              <div className="bg-teal-50 p-6 rounded-lg">
                <h3 className="text-xl font-bold text-gray-900 mb-3">Culture & Heritage</h3>
                <p className="text-gray-700">{destination.culture}</p>
              </div>
              <div className="bg-blue-50 p-6 rounded-lg">
                <h3 className="text-xl font-bold text-gray-900 mb-3">Nature & Landscapes</h3>
                <p className="text-gray-700">{destination.nature}</p>
              </div>
            </div>

            <h3 className="text-2xl font-bold text-gray-900 mb-4">Top Highlights</h3>
            <ul className="space-y-3 mb-8">
              {destination.highlights.map((highlight: string, index: number) => (
                <li key={index} className="flex items-start space-x-3">
                  <Check className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
                  <span className="text-gray-700">{highlight}</span>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <div className="bg-teal-600 text-white p-6 rounded-xl sticky top-20">
              <h3 className="text-2xl font-bold mb-4">Ready to Explore?</h3>
              <p className="mb-6">Book your adventure to {destination.name} today!</p>
              <button
                onClick={() => onNavigate('booking', destinationId)}
                className="w-full bg-white text-teal-600 py-3 rounded-lg font-semibold hover:bg-gray-100 transition-colors"
              >
                Book Now
              </button>
              <button
                onClick={() => onNavigate('packages')}
                className="w-full bg-teal-700 text-white py-3 rounded-lg font-semibold hover:bg-teal-800 transition-colors mt-3"
              >
                View Packages
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* Day-wise Itinerary */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Suggested Itinerary</h2>
          <div className="space-y-6">
            {destination.itinerary.map((day: any) => (
              <div key={day.day} className="bg-white rounded-xl shadow-md p-6">
                <div className="flex items-start space-x-4">
                  <div className="flex-shrink-0">
                    <div className="w-12 h-12 bg-teal-600 text-white rounded-full flex items-center justify-center font-bold">
                      {day.day}
                    </div>
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-bold text-gray-900 mb-3">{day.title}</h3>
                    <ul className="space-y-2">
                      {day.activities.map((activity: string, index: number) => (
                        <li key={index} className="flex items-start space-x-2 text-gray-700">
                          <span className="text-teal-600">•</span>
                          <span>{activity}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Hotels & Resorts */}
      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-3xl font-bold text-gray-900 mb-8">Hotels & Resorts</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {destination.hotels.map((hotel: any) => (
              <div key={hotel.id} className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow">
                <div className="relative h-48">
                  <ImageWithFallback
                    src={hotel.image}
                    alt={hotel.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 right-3 bg-white px-3 py-1 rounded-full text-sm font-semibold">
                    {hotel.category}
                  </div>
                </div>
                <div className="p-5">
                  <h3 className="font-bold text-gray-900 mb-2">{hotel.name}</h3>
                  <p className="text-sm text-gray-600 mb-3 flex items-start">
                    <MapPin className="w-4 h-4 mr-1 flex-shrink-0 mt-0.5" />
                    {hotel.distance}
                  </p>
                  <div className="flex items-center space-x-2 mb-4">
                    {hotel.amenities.map((amenity: string) => (
                      <div
                        key={amenity}
                        className="text-gray-600"
                        title={amenity}
                      >
                        {getAmenityIcon(amenity)}
                      </div>
                    ))}
                  </div>
                  <div className="flex items-end justify-between">
                    <div>
                      <p className="text-2xl font-bold text-teal-600">₹{hotel.price.toLocaleString('en-IN')}</p>
                      <p className="text-xs text-gray-500">per night</p>
                    </div>
                    <button className="bg-teal-600 text-white px-4 py-2 rounded-lg text-sm hover:bg-teal-700 transition-colors">
                      Book
                    </button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Tour Packages */}
      <section className="bg-gray-50 py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Tour Packages</h2>
            <p className="text-xl text-gray-600">Choose the perfect package for your journey</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {destination.packages.map((pkg: any, index: number) => (
              <div
                key={pkg.id}
                className={`bg-white rounded-xl shadow-lg overflow-hidden ${
                  index === 1 ? 'ring-4 ring-teal-600 scale-105' : ''
                }`}
              >
                {index === 1 && (
                  <div className="bg-teal-600 text-white text-center py-2 font-semibold">
                    MOST POPULAR
                  </div>
                )}
                <div className="p-8">
                  <h3 className="text-2xl font-bold text-gray-900 mb-2">{pkg.name}</h3>
                  <p className="text-gray-600 mb-4">{pkg.duration}</p>
                  <div className="mb-6">
                    <span className="text-4xl font-bold text-teal-600">₹{pkg.price.toLocaleString('en-IN')}</span>
                    <span className="text-gray-600"> / person</span>
                  </div>
                  <ul className="space-y-3 mb-8">
                    {pkg.inclusions.map((inclusion: string, idx: number) => (
                      <li key={idx} className="flex items-start space-x-2 text-gray-700">
                        <Check className="w-5 h-5 text-teal-600 flex-shrink-0 mt-0.5" />
                        <span className="text-sm">{inclusion}</span>
                      </li>
                    ))}
                  </ul>
                  <button
                    onClick={() => onNavigate('booking', destinationId)}
                    className={`w-full py-3 rounded-lg font-semibold transition-colors ${
                      index === 1
                        ? 'bg-teal-600 text-white hover:bg-teal-700'
                        : 'bg-gray-100 text-gray-900 hover:bg-gray-200'
                    }`}
                  >
                    Select Package
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}