import { CheckCircle, Download, Calendar, MapPin, Package, DollarSign } from 'lucide-react';
import type { Page, BookingData } from '../App';

interface BookingConfirmationProps {
  bookingData: BookingData;
  onNavigate: (page: Page) => void;
}

export function BookingConfirmation({ bookingData, onNavigate }: BookingConfirmationProps) {
  const bookingId = `BK${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
  
  const handleDownloadItinerary = () => {
    // In a real app, this would generate and download a PDF
    alert('Itinerary download functionality would be implemented here.');
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Success Message */}
        <div className="text-center mb-8">
          <div className="inline-flex items-center justify-center w-20 h-20 bg-green-100 rounded-full mb-4">
            <CheckCircle className="w-12 h-12 text-green-600" />
          </div>
          <h1 className="text-4xl font-bold text-gray-900 mb-2">Booking Confirmed!</h1>
          <p className="text-xl text-gray-600">
            Your adventure awaits! We've sent a confirmation email to {bookingData.email}
          </p>
        </div>

        {/* Booking Details Card */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden mb-6">
          {/* Header */}
          <div className="bg-gradient-to-r from-teal-600 to-blue-600 text-white p-6">
            <div className="flex justify-between items-start">
              <div>
                <h2 className="text-2xl font-bold mb-2">Booking Confirmation</h2>
                <p className="text-teal-100">Booking ID: {bookingId}</p>
              </div>
              <div className="text-right">
                <p className="text-teal-100 text-sm">Confirmation Date</p>
                <p className="font-semibold">{new Date().toLocaleDateString()}</p>
              </div>
            </div>
          </div>

          {/* Details */}
          <div className="p-6 space-y-6">
            {/* Traveler Info */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-2">Traveler Name</h3>
                <p className="text-lg font-semibold text-gray-900">{bookingData.name}</p>
              </div>
              <div>
                <h3 className="text-sm font-medium text-gray-500 mb-2">Contact</h3>
                <p className="text-gray-900">{bookingData.email}</p>
                <p className="text-gray-900">{bookingData.phone}</p>
              </div>
            </div>

            <div className="border-t pt-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {/* Destination */}
                <div className="flex items-start space-x-3">
                  <MapPin className="w-6 h-6 text-teal-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Destination</h3>
                    <p className="text-lg font-semibold text-gray-900">{bookingData.destination}</p>
                  </div>
                </div>

                {/* Travel Dates */}
                <div className="flex items-start space-x-3">
                  <Calendar className="w-6 h-6 text-teal-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Travel Dates</h3>
                    <p className="text-gray-900 font-semibold">
                      {new Date(bookingData.startDate).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric', 
                        year: 'numeric' 
                      })}
                    </p>
                    <p className="text-gray-900">to</p>
                    <p className="text-gray-900 font-semibold">
                      {new Date(bookingData.endDate).toLocaleDateString('en-US', { 
                        month: 'short', 
                        day: 'numeric', 
                        year: 'numeric' 
                      })}
                    </p>
                  </div>
                </div>

                {/* Package */}
                <div className="flex items-start space-x-3">
                  <Package className="w-6 h-6 text-teal-600 flex-shrink-0 mt-1" />
                  <div>
                    <h3 className="text-sm font-medium text-gray-500 mb-1">Selected Package</h3>
                    <p className="text-lg font-semibold text-gray-900 capitalize">
                      {bookingData.packageType} Package
                    </p>
                    <p className="text-sm text-gray-600">{bookingData.travelers} {bookingData.travelers === 1 ? 'Traveler' : 'Travelers'}</p>
                  </div>
                </div>

                {/* Total Amount */}
                <div className="flex items-start space-x-3">
                  <DollarSign className="w-6 h-6 text-teal-600 flex-shrink-0 mt-1" />
                  <div>
                    <h4 className="font-semibold text-gray-900 mb-1">Total Amount Paid</h4>
                    <p className="text-2xl font-bold text-teal-600">
                      ₹{bookingData.totalAmount.toFixed(0).toLocaleString('en-IN')}
                    </p>
                    <p className="text-sm text-gray-600">Payment successful</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Action Buttons */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
          <button
            onClick={handleDownloadItinerary}
            className="bg-teal-600 text-white py-4 rounded-lg font-semibold hover:bg-teal-700 transition-colors flex items-center justify-center space-x-2"
          >
            <Download className="w-5 h-5" />
            <span>Download Itinerary</span>
          </button>
          <button
            onClick={() => onNavigate('home')}
            className="bg-white text-gray-900 py-4 rounded-lg font-semibold border-2 border-gray-300 hover:bg-gray-50 transition-colors"
          >
            Back to Home
          </button>
        </div>

        {/* What's Next */}
        <div className="bg-blue-50 border border-blue-200 rounded-xl p-6">
          <h3 className="text-xl font-bold text-gray-900 mb-4">What's Next?</h3>
          <ul className="space-y-3 text-gray-700">
            <li className="flex items-start">
              <span className="text-blue-600 font-bold mr-3">1.</span>
              <span>Check your email for detailed booking confirmation and itinerary</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-600 font-bold mr-3">2.</span>
              <span>You'll receive travel documents 48 hours before departure</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-600 font-bold mr-3">3.</span>
              <span>Our team will contact you 72 hours before your trip with final details</span>
            </li>
            <li className="flex items-start">
              <span className="text-blue-600 font-bold mr-3">4.</span>
              <span>Download our mobile app for real-time updates during your journey</span>
            </li>
          </ul>
        </div>

        {/* Support Section */}
        <div className="text-center mt-8">
          <p className="text-gray-600 mb-2">Need help with your booking?</p>
          <button
            onClick={() => onNavigate('about')}
            className="text-teal-600 hover:text-teal-700 font-semibold"
          >
            Contact our support team →
          </button>
        </div>
      </div>
    </div>
  );
}