import { MapPin, Star, Wifi, Coffee, Waves, Wind, Search, SlidersHorizontal } from 'lucide-react';
import { useState } from 'react';
import type { Page } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface HotelsResortsProps {
  onNavigate: (page: Page) => void;
}

export function HotelsResorts({ onNavigate }: HotelsResortsProps) {
  const [priceRange, setPriceRange] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');

  const hotels = [
    {
      id: 1,
      name: 'The Laguna Resort & Spa',
      location: 'Seminyak, Bali',
      category: 'Luxury Resort',
      rating: 5,
      reviews: 342,
      image: 'https://images.unsplash.com/photo-1738407282253-979e31f45785?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHBvb2x8ZW58MXx8fHwxNzcwMjcwMjIwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      price: 24999,
      distance: '2 km from beach',
      amenities: ['Wifi', 'Breakfast', 'Pool', 'AC'],
      description: 'Luxury beachfront resort with world-class spa facilities and stunning ocean views'
    },
    {
      id: 2,
      name: 'Ubud Valley Resort',
      location: 'Ubud, Bali',
      category: '5★ Hotel',
      rating: 5,
      reviews: 256,
      image: 'https://images.unsplash.com/photo-1680096025643-d41f6aeff989?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGJlYWNoJTIwcmVzb3J0fGVufDF8fHx8MTc3MDIzMjQ5MHww&ixlib=rb-4.1.0&q=80&w=1080',
      price: 15999,
      distance: '500m from Ubud center',
      amenities: ['Wifi', 'Breakfast', 'Pool', 'AC'],
      description: 'Peaceful retreat surrounded by rice terraces with traditional Balinese architecture'
    },
    {
      id: 3,
      name: 'Nusa Dua Beach Hotel',
      location: 'Nusa Dua, Bali',
      category: '5★ Hotel',
      rating: 5,
      reviews: 428,
      image: 'https://images.unsplash.com/photo-1768735693726-4aead6ae541d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlcmZhbGwlMjBuYXR1cmUlMjB0cm9waWNhbHxlbnwxfHx8fDE3NzAxODcwNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      price: 20999,
      distance: 'Beachfront',
      amenities: ['Wifi', 'Breakfast', 'Pool', 'AC'],
      description: 'Elegant beachfront property with private beach access and water sports facilities'
    },
    {
      id: 4,
      name: 'Canggu Surf Lodge',
      location: 'Canggu, Bali',
      category: '3★ Hotel',
      rating: 4,
      reviews: 189,
      image: 'https://images.unsplash.com/photo-1595368062405-e4d7840cba14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGhpa2luZyUyMGFkdmVudHVyZXxlbnwxfHx8fDE3NzAyMzg1NjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
      price: 7499,
      distance: '300m from beach',
      amenities: ['Wifi', 'Breakfast', 'Pool'],
      description: 'Budget-friendly surf lodge perfect for beach lovers and adventure seekers'
    },
    {
      id: 5,
      name: 'Jimbaran Bay Resort',
      location: 'Jimbaran, Bali',
      category: '4★ Hotel',
      rating: 4,
      reviews: 312,
      image: 'https://images.unsplash.com/photo-1581032841303-0ba9e894ebc3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxCYWxpJTIwSW5kb25lc2lhJTIwdGVtcGxlfGVufDF8fHx8MTc3MDE4ODU4OXww&ixlib=rb-4.1.0&q=80&w=1080',
      price: 13299,
      distance: 'Beachfront',
      amenities: ['Wifi', 'Breakfast', 'Pool', 'AC'],
      description: 'Family-friendly resort with direct beach access and seafood restaurants'
    },
    {
      id: 6,
      name: 'Sanur Beach Villa',
      location: 'Sanur, Bali',
      category: '4★ Hotel',
      rating: 4,
      reviews: 201,
      image: 'https://images.unsplash.com/photo-1719547710130-7ce8ae694d63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdWx0dXJhbCUyMHRlbXBsZSUyMGFzaWF8ZW58MXx8fHwxNzcwMTc3NTU2fDA&ixlib=rb-4.1.0&q=80&w=1080',
      price: 11599,
      distance: '1 km from beach',
      amenities: ['Wifi', 'Breakfast', 'Pool', 'AC'],
      description: 'Charming villa-style accommodation with tropical gardens and peaceful atmosphere'
    }
  ];

  const getAmenityIcon = (amenity: string) => {
    switch (amenity.toLowerCase()) {
      case 'wifi': return <Wifi className="w-4 h-4" />;
      case 'breakfast': return <Coffee className="w-4 h-4" />;
      case 'pool': return <Waves className="w-4 h-4" />;
      case 'ac': return <Wind className="w-4 h-4" />;
      default: return null;
    }
  };

  const filteredHotels = hotels.filter(hotel => {
    const matchesSearch = hotel.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         hotel.location.toLowerCase().includes(searchQuery.toLowerCase());
    
    let matchesPrice = true;
    if (priceRange === 'budget') matchesPrice = hotel.price < 100;
    if (priceRange === 'mid') matchesPrice = hotel.price >= 100 && hotel.price < 200;
    if (priceRange === 'luxury') matchesPrice = hotel.price >= 200;
    
    return matchesSearch && matchesPrice;
  });

  return (
    <div>
      {/* Header */}
      <section className="bg-gradient-to-r from-teal-600 to-blue-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-4">Hotels & Resorts</h1>
          <p className="text-xl text-gray-100 max-w-3xl mx-auto">
            Find your perfect accommodation from budget-friendly to luxury resorts
          </p>
        </div>
      </section>

      {/* Search & Filters */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-10">
        <div className="bg-white rounded-xl shadow-xl p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search hotels..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            {/* Location */}
            <select className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500">
              <option>All Locations</option>
              <option>Seminyak</option>
              <option>Ubud</option>
              <option>Nusa Dua</option>
              <option>Canggu</option>
              <option>Jimbaran</option>
              <option>Sanur</option>
            </select>

            {/* Price Range */}
            <select
              value={priceRange}
              onChange={(e) => setPriceRange(e.target.value)}
              className="px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
            >
              <option value="all">All Prices</option>
              <option value="budget">Budget (&lt; $100)</option>
              <option value="mid">Mid-range ($100-$200)</option>
              <option value="luxury">Luxury ($200+)</option>
            </select>

            {/* Filters Button */}
            <button className="bg-teal-600 text-white px-6 py-3 rounded-lg hover:bg-teal-700 transition-colors flex items-center justify-center space-x-2">
              <SlidersHorizontal className="w-5 h-5" />
              <span>More Filters</span>
            </button>
          </div>
        </div>
      </section>

      {/* Hotels Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="mb-6 flex justify-between items-center">
          <p className="text-gray-600">
            Showing {filteredHotels.length} {filteredHotels.length === 1 ? 'property' : 'properties'}
          </p>
          <select className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500">
            <option>Recommended</option>
            <option>Price: Low to High</option>
            <option>Price: High to Low</option>
            <option>Rating: High to Low</option>
          </select>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {filteredHotels.map((hotel) => (
            <div
              key={hotel.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-xl transition-shadow"
            >
              <div className="flex flex-col sm:flex-row">
                {/* Image */}
                <div className="relative sm:w-64 h-64 sm:h-auto flex-shrink-0">
                  <ImageWithFallback
                    src={hotel.image}
                    alt={hotel.name}
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute top-3 right-3 bg-white px-3 py-1 rounded-full text-sm font-semibold">
                    {hotel.category}
                  </div>
                </div>

                {/* Details */}
                <div className="flex-1 p-6 flex flex-col">
                  <div className="flex-1">
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-bold text-gray-900">{hotel.name}</h3>
                      <div className="flex items-center text-yellow-500">
                        {[...Array(hotel.rating)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 fill-current" />
                        ))}
                      </div>
                    </div>

                    <p className="text-gray-600 text-sm mb-1 flex items-center">
                      <MapPin className="w-4 h-4 mr-1" />
                      {hotel.location} • {hotel.distance}
                    </p>

                    <p className="text-gray-700 text-sm mb-4">{hotel.description}</p>

                    {/* Amenities */}
                    <div className="flex items-center space-x-3 mb-4">
                      {hotel.amenities.map((amenity) => (
                        <div
                          key={amenity}
                          className="flex items-center space-x-1 text-gray-600"
                          title={amenity}
                        >
                          {getAmenityIcon(amenity)}
                          <span className="text-xs">{amenity}</span>
                        </div>
                      ))}
                    </div>

                    <p className="text-sm text-gray-600">
                      <Star className="w-4 h-4 inline text-yellow-500 fill-current" />
                      {' '}{hotel.rating.toFixed(1)} ({hotel.reviews} reviews)
                    </p>
                  </div>

                  {/* Price & Book */}
                  <div className="flex items-end justify-between mt-4 pt-4 border-t">
                    <div>
                      <p className="text-xs text-gray-500">From</p>
                      <p className="text-3xl font-bold text-teal-600">₹{hotel.price.toLocaleString('en-IN')}</p>
                      <p className="text-xs text-gray-500">per night</p>
                    </div>
                    <button
                      onClick={() => onNavigate('booking')}
                      className="bg-teal-600 text-white px-6 py-3 rounded-lg hover:bg-teal-700 transition-colors font-semibold"
                    >
                      Book Now
                    </button>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredHotels.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-600 text-xl">No hotels found matching your criteria.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setPriceRange('all');
              }}
              className="mt-4 text-teal-600 hover:text-teal-700 font-semibold"
            >
              Clear filters
            </button>
          </div>
        )}
      </section>
    </div>
  );
}