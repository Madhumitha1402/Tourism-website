import { Calendar, ArrowRight, Search, Filter } from 'lucide-react';
import { useState } from 'react';
import type { Page } from '../App';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface DestinationsProps {
  onNavigate: (page: Page, destination?: string) => void;
}

export function Destinations({ onNavigate }: DestinationsProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedFilter, setSelectedFilter] = useState('all');

  const destinations = [
    {
      id: 'bali',
      name: 'Bali, Indonesia',
      description: 'Tropical paradise with stunning beaches, ancient temples, and vibrant culture',
      image: 'https://images.unsplash.com/photo-1581032841303-0ba9e894ebc3?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxCYWxpJTIwSW5kb25lc2lhJTIwdGVtcGxlfGVufDF8fHx8MTc3MDE4ODU4OXww&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '5-7 Days',
      price: 'From ₹74,999',
      category: 'beach',
      continent: 'Asia'
    },
    {
      id: 'santorini',
      name: 'Santorini, Greece',
      description: 'Iconic white-washed buildings overlooking the azure Aegean Sea',
      image: 'https://images.unsplash.com/photo-1719547710130-7ce8ae694d63?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjdWx0dXJhbCUyMHRlbXBsZSUyMGFzaWF8ZW58MXx8fHwxNzcwMTc3NTU2fDA&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '4-6 Days',
      price: 'From ₹1,07,999',
      category: 'beach',
      continent: 'Europe'
    },
    {
      id: 'maldives',
      name: 'Maldives',
      description: 'Luxury overwater bungalows in crystal-clear turquoise waters',
      image: 'https://images.unsplash.com/photo-1680096025643-d41f6aeff989?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx0cm9waWNhbCUyMGJlYWNoJTIwcmVzb3J0fGVufDF8fHx8MTc3MDIzMjQ5MHww&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '5-8 Days',
      price: 'From ₹1,49,999',
      category: 'beach',
      continent: 'Asia'
    },
    {
      id: 'patagonia',
      name: 'Patagonia, Argentina',
      description: 'Breathtaking mountains, glaciers, and pristine wilderness',
      image: 'https://images.unsplash.com/photo-1595368062405-e4d7840cba14?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxtb3VudGFpbiUyMGhpa2luZyUyMGFkdmVudHVyZXxlbnwxfHx8fDE3NzAyMzg1NjB8MA&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '7-10 Days',
      price: 'From ₹1,24,999',
      category: 'adventure',
      continent: 'South America'
    },
    {
      id: 'paris',
      name: 'Paris, France',
      description: 'The City of Light with iconic landmarks, art, and cuisine',
      image: 'https://images.unsplash.com/photo-1768735693726-4aead6ae541d?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHx3YXRlcmZhbGwlMjBuYXR1cmUlMjB0cm9waWNhbHxlbnwxfHx8fDE3NzAxODcwNDZ8MA&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '4-6 Days',
      price: 'From ₹99,999',
      category: 'city',
      continent: 'Europe'
    },
    {
      id: 'tokyo',
      name: 'Tokyo, Japan',
      description: 'Modern metropolis blending tradition with cutting-edge technology',
      image: 'https://images.unsplash.com/photo-1738407282253-979e31f45785?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxsdXh1cnklMjBob3RlbCUyMHBvb2x8ZW58MXx8fHwxNzcwMjcwMjIwfDA&ixlib=rb-4.1.0&q=80&w=1080',
      duration: '5-7 Days',
      price: 'From ₹91,999',
      category: 'city',
      continent: 'Asia'
    }
  ];

  const filters = [
    { id: 'all', label: 'All Destinations' },
    { id: 'beach', label: 'Beach & Islands' },
    { id: 'adventure', label: 'Adventure' },
    { id: 'city', label: 'City Breaks' }
  ];

  const filteredDestinations = destinations.filter(dest => {
    const matchesSearch = dest.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         dest.description.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = selectedFilter === 'all' || dest.category === selectedFilter;
    return matchesSearch && matchesFilter;
  });

  return (
    <div>
      {/* Header */}
      <section className="bg-gradient-to-r from-teal-600 to-blue-600 text-white py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-5xl font-bold mb-4">Explore Destinations</h1>
          <p className="text-xl text-gray-100 max-w-3xl mx-auto">
            Discover amazing places around the world and plan your perfect getaway
          </p>
        </div>
      </section>

      {/* Search & Filters */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-8 relative z-10">
        <div className="bg-white rounded-xl shadow-xl p-6">
          <div className="flex flex-col md:flex-row gap-4">
            {/* Search Bar */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <input
                type="text"
                placeholder="Search destinations..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-teal-500"
              />
            </div>

            {/* Filter Buttons */}
            <div className="flex items-center space-x-2">
              <Filter className="text-gray-600 w-5 h-5" />
              <div className="flex flex-wrap gap-2">
                {filters.map(filter => (
                  <button
                    key={filter.id}
                    onClick={() => setSelectedFilter(filter.id)}
                    className={`px-4 py-2 rounded-lg transition-colors ${
                      selectedFilter === filter.id
                        ? 'bg-teal-600 text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {filter.label}
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Destinations Grid */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredDestinations.map((destination) => (
            <div
              key={destination.id}
              className="bg-white rounded-xl shadow-lg overflow-hidden hover:shadow-2xl transition-all transform hover:-translate-y-1 cursor-pointer"
              onClick={() => onNavigate('destination-details', destination.id)}
            >
              <div className="relative h-64">
                <ImageWithFallback
                  src={destination.image}
                  alt={destination.name}
                  className="w-full h-full object-cover"
                />
                <div className="absolute top-4 right-4 bg-white px-3 py-1 rounded-full text-sm font-semibold text-teal-600">
                  {destination.price}
                </div>
                <div className="absolute top-4 left-4 bg-black/50 text-white px-3 py-1 rounded-full text-xs">
                  {destination.continent}
                </div>
              </div>
              <div className="p-6">
                <h3 className="text-2xl font-bold text-gray-900 mb-2">{destination.name}</h3>
                <p className="text-gray-600 mb-4">{destination.description}</p>
                <div className="flex items-center justify-between text-sm">
                  <div className="flex items-center space-x-1 text-gray-500">
                    <Calendar className="w-4 h-4" />
                    <span>{destination.duration}</span>
                  </div>
                  <button
                    onClick={(e) => {
                      e.stopPropagation();
                      onNavigate('destination-details', destination.id);
                    }}
                    className="text-teal-600 hover:text-teal-700 font-semibold flex items-center space-x-1"
                  >
                    <span>Explore</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>

        {filteredDestinations.length === 0 && (
          <div className="text-center py-16">
            <p className="text-gray-600 text-xl">No destinations found matching your criteria.</p>
            <button
              onClick={() => {
                setSearchQuery('');
                setSelectedFilter('all');
              }}
              className="mt-4 text-teal-600 hover:text-teal-700 font-semibold"
            >
              Clear filters
            </button>
          </div>
        )}
      </section>
    </div>
  );
}