import { useState } from 'react';
import { Home } from './components/Home';
import { Destinations } from './components/Destinations';
import { DestinationDetails } from './components/DestinationDetails';
import { HotelsResorts } from './components/HotelsResorts';
import { TourPackages } from './components/TourPackages';
import { Booking } from './components/Booking';
import { BookingConfirmation } from './components/BookingConfirmation';
import { About } from './components/About';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';

export type Page = 'home' | 'destinations' | 'destination-details' | 'hotels' | 'packages' | 'booking' | 'confirmation' | 'about';

export interface BookingData {
  name: string;
  email: string;
  phone: string;
  startDate: string;
  endDate: string;
  travelers: number;
  packageType: string;
  destination: string;
  totalAmount: number;
}

export default function App() {
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedDestination, setSelectedDestination] = useState<string>('bali');
  const [bookingData, setBookingData] = useState<BookingData | null>(null);

  const navigateTo = (page: Page, destination?: string) => {
    if (destination) {
      setSelectedDestination(destination);
    }
    setCurrentPage(page);
    window.scrollTo(0, 0);
  };

  const handleBookingSubmit = (data: BookingData) => {
    setBookingData(data);
    navigateTo('confirmation');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <Navbar currentPage={currentPage} onNavigate={navigateTo} />
      
      <main>
        {currentPage === 'home' && <Home onNavigate={navigateTo} />}
        {currentPage === 'destinations' && <Destinations onNavigate={navigateTo} />}
        {currentPage === 'destination-details' && (
          <DestinationDetails 
            destinationId={selectedDestination} 
            onNavigate={navigateTo} 
          />
        )}
        {currentPage === 'hotels' && <HotelsResorts onNavigate={navigateTo} />}
        {currentPage === 'packages' && <TourPackages onNavigate={navigateTo} />}
        {currentPage === 'booking' && (
          <Booking 
            destination={selectedDestination}
            onSubmit={handleBookingSubmit}
            onNavigate={navigateTo}
          />
        )}
        {currentPage === 'confirmation' && bookingData && (
          <BookingConfirmation bookingData={bookingData} onNavigate={navigateTo} />
        )}
        {currentPage === 'about' && <About />}
      </main>

      <Footer onNavigate={navigateTo} />
    </div>
  );
}
